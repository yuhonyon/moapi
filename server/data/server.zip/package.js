
{
  "name": "mock-server",
  "scripts": {
    "start": "node app.js",
    "dev": "./node_modules/.bin/nodemon app.js"
  },
  "dependencies": {
    "debug": "^2.6.3",
    "ejs": "^2.5.7",
    "koa": "^2.2.0",
    "koa-bodyparser": "^3.2.0",
    "koa-convert": "^1.2.0",
    "koa-cors": "^0.0.16",
    "koa-json": "^2.0.2",
    "koa-logger": "^2.0.1",
    "koa-onerror": "^1.2.1",
    "koa-router": "^7.1.1",
    "koa-static": "^3.0.0",
    "koa-views": "^5.2.1",
    "koa2-pixie-proxy": "^2.0.3"
  },
  "devDependencies": {
    "nodemon": "^1.8.1"
  }
}
